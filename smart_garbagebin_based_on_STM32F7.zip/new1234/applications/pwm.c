#include <rtthread.h>
#include <rtdevice.h>
#include <stdlib.h>     // 用于 atoi

#define PWM_DEV_NAME        "pwm2"     /* PWM设备名称 */
#define PWM_DEV_CHANNEL     3          /* PWM通道 */

struct rt_device_pwm *pwm_dev;         /* PWM设备句柄 */

/* 角度（0-180）转换为脉宽（500000ns - 2500000ns） */
static rt_uint32_t angle_to_pulse(rt_uint8_t angle)
{
    rt_uint32_t min_pulse = 500000;    // 0.5ms
    rt_uint32_t max_pulse = 2500000;   // 2.5ms
    if (angle > 180) angle = 180;

    return min_pulse + (max_pulse - min_pulse) * angle / 180;
}

/* 新函数：控制舵机根据时间转动 */
static int servo_rotate_by_time(int argc, char *argv[])
{
    if (argc != 2)
    {
        rt_kprintf("Usage: pwm_servo_rotate_by_time <time in ms>\n");
        return -RT_ERROR;
    }

    rt_int32_t time = atoi(argv[1]);
    if (time == 0)
    {
        rt_kprintf("Time cannot be 0, it must be non-zero.\n");
        return -RT_ERROR;
    }

    rt_uint32_t period = 20000000; // 20ms周期
    rt_uint32_t pulse;

    if (time > 0)
    {
        /* 右转 */
        pulse = angle_to_pulse(180);  // 最大右转
        rt_kprintf("Right rotation for %d ms\n", time);
    }
    else
    {
        /* 左转 */
        pulse = angle_to_pulse(0);  // 最大左转
        rt_kprintf("Left rotation for %d ms\n", time);
    }

    pwm_dev = (struct rt_device_pwm *)rt_device_find(PWM_DEV_NAME);
    if (pwm_dev == RT_NULL)
    {
        rt_kprintf("Failed to find device: %s\n", PWM_DEV_NAME);
        return -RT_ERROR;
    }

    /* 设置PWM脉宽 */
    rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL, period, pulse);
    rt_pwm_enable(pwm_dev, PWM_DEV_CHANNEL);

    /* 按时间控制转动 */
    rt_thread_mdelay(abs(time)); // 使用绝对值确保时间为正

    /* 停止舵机 */
    pulse = angle_to_pulse(90);  // 停止时的脉宽为90°（中位）
    rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL, period, pulse);
    rt_kprintf("Stopped after %d ms\n", time);

    return RT_EOK;
}

/* 导出命令到 msh 中 */
MSH_CMD_EXPORT(servo_rotate_by_time, Rotate servo by time (ms) via pwm3 channel 1. Usage: pwm_servo_rotate_by_time <time_in_ms>);
