# 训练模型
from ultralytics import YOLO

# 加载预训练模型

a1 = YOLO('models/yolov8n.pt')
# 开始训练模型
if __name__ == '__main__':
    a1.train(
        data='qianrushi.yaml',  # 数据集配置文件路径
        epochs=500,  # 训练轮次
        imgsz=640,  # 训练尺寸，推荐640
        batch=32,  # 每次训练的批量（推荐32）
        device=0  # 用cpu训练，用GPU就填0
    )

print("模型训练完毕")
